from selenium import webdriver
# from trueMain import num
import trueMain
import time


option = webdriver.ChromeOptions()
option.binary_location = r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'

# 数据
month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# 获取时间，账号，密码
localtime = time.localtime(time.time())
yea = localtime.tm_year
mon = localtime.tm_mon
day = localtime.tm_mday
dayStr1 = 'https://selfreport.shu.edu.cn/XueSFX/HalfdayReport.aspx?day=' \
          + str(yea) + '-' + str(mon) + '-' + str(day) + '&t=1'
dayStr2 = 'https://selfreport.shu.edu.cn/XueSFX/HalfdayReport.aspx?day=' \
          + str(yea) + '-' + str(mon) + '-' + str(day) + '&t=2'
username = input("请输入您的账号")
password = input("请输入您的密码")
flag = 1
mark = 1

while 1:
    if mon == 1 and day == 1:
        print("报送完毕")
        break
    try:
        # 登录页面1
        driver = webdriver.Chrome()
        if flag == 1:
            driver.get(dayStr1)
        else:
            driver.get(dayStr2)

        # 输入账号密码登录页面2
        input1 = driver.find_element_by_id("username")
        input2 = driver.find_element_by_id("password")
        input3 = driver.find_element_by_id("submit")
        input1.send_keys(username)
        input2.send_keys(password)
        input3.click()
        time.sleep(1)

        # 开始报送
        input4 = driver.find_element_by_id('p1_ChengNuo-inputEl-icon')
        input4.click()
        input5 = driver.find_element_by_id('p1_TiWen-inputEl')
        if input4.is_selected():
            mark = 0
        else:
            mark = 1
            input5.send_keys('36')
            input6 = driver.find_element_by_id('fineui_12-inputEl-icon')
            input7 = driver.find_element_by_id('fineui_14-inputEl-icon')
            input8 = driver.find_element_by_id('fineui_18-inputEl-icon')
            input9 = driver.find_element_by_id('fineui_20-inputEl-icon')
            input6.click()
            input7.click()
            input8.click()
            input9.click()
            input10 = driver.find_element_by_xpath('//*[@id="p1_ctl00_btnSubmit"]/span/span')  # 提一次提交
            input10.click()
            time.sleep(1)
            input11 = driver.find_element_by_id('fineui_33')
            input11.click()
            # input11 = driver.find_element_by_id('fineui_37')
            # input11.click()
            time.sleep(1)
        driver.quit()

        if flag == 1 and mark == 1:
            print("当前报送好了: " + str(yea) + "年" + str(mon) + "月" + str(day) + "日的晨报")
        elif flag == 0 and mark == 1:
            print("当前报送好了: " + str(yea) + "年" + str(mon) + "月" + str(day) + "日的晚报")
        elif flag == 1:
            print(str(yea) + "年" + str(mon) + "月" + str(day) + "日的晨报早就已经报送完毕")
        else:
            print(str(yea) + "年" + str(mon) + "月" + str(day) + "日的晚报早就已经报送完毕")

        if flag == 1:
            flag = 0
        else:
            if day == 1:
                mon -= 1
                day = month[mon]
            else:
                day -= 1
            dayStr1 = 'https://selfreport.shu.edu.cn/XueSFX/HalfdayReport.aspx?day=' \
                      + str(yea) + '-' + str(mon) + '-' + str(day) + '&t=1'
            dayStr2 = 'https://selfreport.shu.edu.cn/XueSFX/HalfdayReport.aspx?day=' \
                      + str(yea) + '-' + str(mon) + '-' + str(day) + '&t=2'
            flag = 1
    except Exception:
        print("当前被ban，暂停一下")
        driver.quit()
        time.sleep(20)
        continue
    else:
        continue





