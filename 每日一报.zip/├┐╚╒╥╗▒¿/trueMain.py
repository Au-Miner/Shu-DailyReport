import os


def work():
    os.system("main.py")


if __name__ == '__main__':
    work()

